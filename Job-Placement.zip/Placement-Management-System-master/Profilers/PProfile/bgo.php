<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
<nav class="templatemo-left-nav">          
          <ul>
		  
<li><a href="computer.php"><i class="fa fa-home fa-fw"></i>Computer</a></li>
<li><a href="mechanical.php"><i class="fa fa-home fa-fw"></i>Mechanical</a></li>
<li><a href="civil.php"><i class="fa fa-home fa-fw"></i>Civil</a></li>
          </ul>  
        </nav>
</body>
</html>